Simulation of page replacement algorithms
=========================================

pra-sim.tex is the main document.  Read LICENSE about licensing
issues.

The source directory contains the Python sources.  Run source/demo.py
for a demonstration on how to use the scripts.  It needs gnuplot-py_,
which needs Gnuplot_ and the `Numeric Python Extension`_.  Please make
sure that these packages are installed.

.. _gnuplot-py: http://gnuplot-py.sourceforge.net/
.. _`Numeric Python Extension`: http://numpy.sourceforge.net/
.. _Gnuplot: http://www.gnuplot.info/
.. _Python: http://www.python.org/
